//
//  ViewController.swift
//  memuDemo
//
//  Created by Parth Changela on 09/10/16.
//  Copyright © 2016 Parth Changela. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func share(_ sender: Any) {
        
        let activityVC = UIActivityViewController(activityItems: ["https://play.google.com/store/apps/details?id=com.nirvanza"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
        
    }
    
    @IBAction func shareBottom(_ sender: Any) {
        let shareText = "Hello, world!"
        
        if let image = UIImage(named: "logo.jpg") {
            let vc = UIActivityViewController(activityItems: [shareText, image], applicationActivities: [])
            present(vc, animated: true)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
   
            
        }
    }





